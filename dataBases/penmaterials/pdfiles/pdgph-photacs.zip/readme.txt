PENELOPE reads the atomic cross sections for photoelectric absorption
from the files 'pdgphZZ.p18' (ZZ = atomic number) in the directory
'/pendbase/pdfiles' of the distribution package. These files were
calculated by running the program PHOTACS of Sabbatucci and Salvat
(2016) with the screening normalisation correction included. Although
this correction seems to improve agreement with dose measurements, its
consistency with the theory underlying the calculations of the
photoeffect is debatable.

The present compressed file contains an alternative database of
photoelectric cross sections that were calculated without the screening
normalisation correction. To run PENELOPE without that correction,
uncompress the present file and copy the files 'pdgphZZ.p18' from the
directory 'pdgph-photacs' into the directory '/pendbase/pdfiles' of
the PENELOPE directory tree, overwriting the exiting files. To use the
uncorrected cross sections, you must generate new material data files
(by running the programs 'material' or 'tables').

Reference: L. Sabbatucci and F. Salvat (2016), "Theory and calculation
of the atomic photoeffect," Rad. Phys. Chem. 121, 122-140.

